def get_employees():
    print("Получение списка сотрудников")