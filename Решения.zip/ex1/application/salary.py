def calculate_salary():
    print("Расчет зарплаты")